                                                       !!! PLEASE READ THIS !!!

This is it - the 'Very Best of GUS MIDI' collection.

All you will ever need to impress your friends!


This compilation was done by Gerd R. with the help of many people on the
Internet (see last section for thanks and greetings).
It is a collection of over 250 MIDI files that sound great on the GUS (Gravis
Ultrasound) and probably any other General Midi soundcard.

The compilation is intended for the MIDI-interested GUS owner who doesn't want
to listen to the thousands(!) of MIDI files available on the Internet to find
out which files actually are good. I did and I tell you it wasn't always easy
to listen to the many badly done and incorrectly voiced files. This compilation
represents only my personal taste so maybe you won't like some of the files.
But since this compilation includes many different styles of music I'm sure you
will find some tunes you like.


All these files have only been tried out with PLAYMIDI version 5.04 on a GUS
with 1 MB onboard memory. There may be difficulties playing some of these files
with Windows (especially the PIANO files). The file L1002_06.MID must be played
using the -8 switch (loading the patches at 8 bit resolution).


The compilation is split up into three parts:

  Classic :  classical music
  Piano   :  piano only music
  Pop     :  all other music
  
Ok ok, I know that this classification is not great, but I just don't feel
authorized to distinguish between Pop, Rock, Jazz, Folk etc. so I put all that
into 'Pop'.

  
As far as I know, all of these MIDI files are freely distributable, but most of
them are copyrighted. Many of these files were downloaded from various
Anonymous FTP servers, so I hope that distributing them is not prohibited. If
I should break any laws by doing this please tell me.

----

This compilation couldn't have been done without the help of these nice people:

Eric, Gerard, Jim, John, Jojo, Keijo, Martin, Nanite, Peter, Raphael, Rod, Ron,
Scott, Viktor, Will
and all other people who sent me MIDI files - thank you very much -

and of course all the unknown composers of these beautiful pieces of music.


Greetings go to all the *powerful* ppl on IRC, especially

AndrewM, dome, double-j, DragonMaster, FAZ, FireTrack, Gunslinger, jgint, Jojo,
Nanite, pCk, Sebastian, super-io, Trilobyte

and to all the ppl I have forgotten (kick me next time you see me on IRC ;) )

----

One thing is very important for me: Whatever you think about this compilation -
if you find it great or awful - essential or useless - PLEASE tell me!

Email your comments/gratulations/thanks/flames to:

  greichin@cslab.tuwien.ac.at
               
               (Attention: my email address will change in summer '94)

Thank you very much,
                     Gerd.


Gerd R. is a student (but not a representative!) of TU Vienna, Austria, Europe.
You can find him as 'Powergerd' on channels #GUS and #Doom on IRC.

-----

P.S: 
If you don't know where to start, try some of my favourites: 692-moon, 8183,
dasboot, go_west, klar, opus1, ppanth32, psr510_4, stomp and twinpeak.

Watch out for future versions of the 'Very Best of GUS MIDI' collection ...